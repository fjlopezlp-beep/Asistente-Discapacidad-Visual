// TFM: Asistente para personas con discapacidad visual
// Fco Javier López López
// Versión PRO: Corrección híbrida (Levenshtein + Fonética + Contexto)
// Fecha: 2026-06-08
// Esta es la version de trabajo final, con corrección avanzada y sistema de evaluación integrado.
// Se han añadido funciones para calcular CER y WER, así como para guardar los resultados de cada experimento en un CSV y JSON.
// Además, se ha implementado un filtro de idioma para mejorar la precisión del OCR en etiquetas que puedan contener texto en inglés.
// La corrección de contexto utiliza n-gramas para identificar patrones comunes en ingredientes alimentarios,
// lo que mejora significativamente la corrección de errores en el texto detectado.

import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:camera/camera.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'dart:math';
import 'package:permission_handler/permission_handler.dart';
import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';

// ==========================================================
// MÉTRICAS DE RENDIMIENTO
// ==========================================================

class MetricasRendimiento {
  static int captura = 0;
  static int ocr = 0;
  static int correccion = 0;
  static int alergenos = 0;
  static int tts = 0;
  static int total = 0;
  static int tiempoCaptura = 0; // Variable para almacenar el tiempo de captura en milisegundos

  static void reset() {
    captura = 0;
    ocr = 0;
    correccion = 0;
    alergenos = 0;
    tts = 0;
    total = 0;
    tiempoCaptura = 0;
  }
}

// =========================================================
// Función principal de la aplicación
// =========================================================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final cameras = await availableCameras();

  await Permission.storage.request(); // PEDIR PERMISO DE ALMACENAMIENTO

  runApp(
    MaterialApp(
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: CameraScreen(camera: cameras.first),
    ),
  );
}

// =====================================================
// CREAR CARPETA DE EXPERIMENTOS TFM
// =====================================================

Future<Directory> obtenerCarpetaTFM() async {
  final carpeta = Directory('/storage/emulated/0/Download/TFM_OCR');

  if (!await carpeta.exists()) {
    await carpeta.create(recursive: true);
  }

  return carpeta;
}

// =========================================================
// VARIABLES GLOBALES
// =========================================================
Map<String, dynamic> erroresOCR = {};
Set<String> diccionarioAdaptativo =
    {}; // DICIONARIO ADAPTATIVO PARA APRENDIZAJE DE ERRORES

// =========================================================
// VARIABLES LOCALES
// =========================================================

String textoOCR = "";
String textoCorregido = "";
String ultimoOCRBruto = "";
String ultimoOCROriginal = "";
String ultimoOCRCorregido = "";
List<String> diccionarioUsuario = []; // Variable local para ML

// ========== PANTALLA DE CÁMARA ==========
class CameraScreen extends StatefulWidget {
  final CameraDescription camera;
  const CameraScreen({super.key, required this.camera});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

// ==========Estado de la pantalla de cámara ==========
class _CameraScreenState extends State<CameraScreen> {
  late CameraController _controller;
  late Future<void> _init;

  final Stopwatch swCaptura =
      Stopwatch(); // Cronómetro para medir el tiempo de captura
  int tiempoCaptura =
      0; // Variable para almacenar el tiempo de captura en milisegundos

  @override
  void initState() {
    super.initState();
    _controller = CameraController(widget.camera, ResolutionPreset.high);
    _init = _controller.initialize();
    // await _tts.speak("Aplicación iniciada. Apunta a la etiqueta y toca la pantalla.");
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _capturar() async {
    // Iniciar cronómetro cuando el usuario pulsa el botón
    swCaptura.reset();
    swCaptura.start();

    await _init;

    // Espera a que la cámara haga la fotografía
    final foto = await _controller.takePicture();

    // Detener cronómetro
    swCaptura.stop();

    // Tiempo de captura en milisegundos
    MetricasRendimiento.tiempoCaptura = swCaptura.elapsedMilliseconds;

    debugPrint("Tiempo captura: ${MetricasRendimiento.tiempoCaptura} ms");

    final bytes = await File(foto.path).readAsBytes();
    img.Image? image = img.decodeImage(bytes);

    if (image != null) {
      img.Image cropped = img.copyCrop(
        image,
        x: 0,
        y: 0,
        width: image.width,
        height: (image.height * 2 / 3).toInt(),
      );

      final dir = await obtenerCarpetaTFM();

      final nombre = DateTime.now().millisecondsSinceEpoch;

      final path = '${dir.path}/img_$nombre.png';

      //await _tts.speak("Imagen capturada. Procesando texto.");
      HapticFeedback.mediumImpact(); // añade vibracion

      File(path).writeAsBytesSync(img.encodePng(cropped));

      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ResultScreen(imagePath: path)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: GestureDetector(
        onTap: _capturar,
        child: Stack(
          children: [
            // Cámara
            FutureBuilder(
              future: _init,
              builder: (_, snap) {
                return snap.connectionState == ConnectionState.done
                    ? SizedBox.expand(child: CameraPreview(_controller))
                    : const Center(child: CircularProgressIndicator());
              },
            ),

            // MÁSCARA OSCURA
            ColorFiltered(
              colorFilter: const ColorFilter.mode(
                Colors.black54,
                BlendMode.srcOut,
              ),
              child: Stack(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      color: Colors.black,
                      backgroundBlendMode: BlendMode.dstOut,
                    ),
                  ),

                  // ZONA VISIBLE (OCR)
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: size.width,
                      height: size.height * (2 / 3),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(color: Colors.redAccent, width: 2),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // esto es una prueba para dos lineas de texto
            const Align(
              alignment: Alignment(0, 0.85),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "TOCA LA PANTALLA Y CAPTURA Versión de Evaluación 1.2",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      backgroundColor: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    "TFM: ASISTENTE PARA PERSONAS CON DISCAPACIDAD VISUAL",
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      backgroundColor: Colors.black54,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================= LINEAS DE TEXTO INFORMATIVAS =================

class EvaluacionOCR {
  static Future<void> guardarExperimento({
    required String imagen,
    required String textoReal,
    required String ocr,
    required String corregido,
    required double cerOCR,
    required double cerCorregido,
    required double werOCR,
    required double werCorregido,
    required int tiempoCaptura,
  }) async {
    final carpeta = await obtenerCarpetaTFM();

    final fichero = File('${carpeta.path}/experimentos.csv');

    print("Guardando CSV en:");
    print(fichero.path);

    if (!await fichero.exists()) {
      await fichero.writeAsString(
        'fecha,imagen,texto_real,ocr,ocr_corregido,cer_ocr,cer_corregido,wer_ocr,wer_corregido\n',
      );

      print("CSV creado");
    }

    await fichero.writeAsString(
      '${DateTime.now().toIso8601String()},"$imagen","$textoReal","$ocr","$corregido",$cerOCR,$cerCorregido,$werOCR,$werCorregido\n',
      mode: FileMode.append,
    );

    print("Fila añadida");

    // Limpiar saltos de línea
    textoReal = textoReal.replaceAll('\n', ' ').replaceAll('\r', ' ');

    ocr = ocr.replaceAll('\n', ' ').replaceAll('\r', ' ');

    corregido = corregido.replaceAll('\n', ' ').replaceAll('\r', ' ');

    // Escapar comillas para CSV
    textoReal = textoReal.replaceAll('"', '""');
    ocr = ocr.replaceAll('"', '""');
    corregido = corregido.replaceAll('"', '""');

    // Formato numérico
    String cerOCRTxt = cerOCR.toStringAsFixed(6);

    String cerCorTxt = cerCorregido.toStringAsFixed(6);

    String werOCRTxt = werOCR.toStringAsFixed(6);

    String werCorTxt = werCorregido.toStringAsFixed(6);

    final linea =
        '${DateTime.now()};'
        '"$imagen";'
        '"$textoReal";'
        '"$ocr";'
        '"$corregido";'
        '$cerOCRTxt;'
        '$cerCorTxt;'
        '$werOCRTxt;'
        '$werCorTxt\n';

    // await fichero.writeAsString(
    //   linea,
    //   mode: FileMode.append,
    // );

    print("Experimento guardado:");
    print(linea);
  }
}
// ================= RESULTADO =================

class ResultScreen extends StatefulWidget {
  final String imagePath;

  const ResultScreen({
    super.key,
    required this.imagePath,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

  const ResultScreen({
    super.key,
    required this.imagePath,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  final FlutterTts _tts = FlutterTts();
  String _resultado = "Analizando...";

  // NUEVO
  final TextEditingController realController = TextEditingController();

  List<String> diccionario = [];
  List<String> unigramas = [];
  List<String> bigramas = [];
  List<String> trigramas = [];
  List<String> cuatrigramas = [];

  final Set<String> palabrasClave = {
    "arroz",
    "pollo",
    "lactosa",
    "gluten",
    "trigo",
    "leche",
    "cebada",
    "centeno",
    "huevo",
    "soja",
    "pescado",
    "marisco",
  };

  // ===== palabras comunes en etiquetas de alimentos ========
  final palabrasAlimentos = [
    "ingredientes",
    "agua",
    "aceite",
    "sal",
    "azucar",
    "azúcar",
    "huevo",
    "leche",
    "gluten",
    "conservador",
    "estabilizante",
    "aroma",
    "vinagre",
    "maiz",
    "maíz",
    "girasol",
    "trigo",
  ];

  // ================ LISTA DE PALABRAS INGLESAS =======
  final List<String> palabrasIngles = [
    "ingredients",
    "sunflower",
    "weight",
    "best before",
    "vinegar",
    "starch",
    "preservative",
    "sugar",
    "spirit",
    "egg yolk",
    "net weight",
  ];

  // ================= NORMALIZAR =================
  String normalizar(String t) => t
      .toLowerCase()
      .replaceAll(RegExp(r'[áàä]'), 'a')
      .replaceAll(RegExp(r'[éèë]'), 'e')
      .replaceAll(RegExp(r'[íìï]'), 'i')
      .replaceAll(RegExp(r'[óòö]'), 'o')
      .replaceAll(RegExp(r'[úùü]'), 'u');

  // ================= NORMALIZAR CER/WER =================
  String normalizarWER(String texto) {
    texto = normalizar(texto);
    texto = texto.replaceAll(RegExp(r'[^\w\s]'), '');

    texto = texto.replaceAll(RegExp(r'\s+'), ' ');

    return texto.trim();
  }

  // ================= FONÉTICA =================
  String fonetizar(String palabra) {
    return normalizar(palabra)
        .replaceAll(RegExp(r'[bv]'), 'b')
        .replaceAll(RegExp(r'[ckq]'), 'k')
        .replaceAll('z', 's')
        .replaceAll('ll', 'y')
        .replaceAll('h', '')
        .replaceAll(RegExp(r'[^a-z]'), '');
  }

  // ================= LIMPIEZA OCR =================
  String limpiar(String p) =>
      p.toLowerCase().replaceAll(RegExp(r'[^a-záéíóúüñ]'), '');

  // ================= LEVENSHTEIN =================
  int dist(String a, String b) {
    final dp = List.generate(a.length + 1, (_) => List.filled(b.length + 1, 0));

    for (int i = 0; i <= a.length; i++) dp[i][0] = i;
    for (int j = 0; j <= b.length; j++) dp[0][j] = j;

    for (int i = 1; i <= a.length; i++) {
      for (int j = 1; j <= b.length; j++) {
        int cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = [
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost,
        ].reduce((x, y) => x < y ? x : y);
      }
    }
    return dp[a.length][b.length];
  }

  // ================= CORRECCIÓN PRO =================
  String corregirPalabra(String palabra) {
    String limpia = limpiar(palabra);

    final palabraNorm = palabra.toLowerCase();

    if (diccionario.contains(palabraNorm)) {
      return palabra;
    }

    if (diccionarioAdaptativo.contains(palabraNorm)) {
      return palabra;
    }

    if (erroresOCR.containsKey(palabraNorm)) {
      final info = erroresOCR[palabraNorm];

      if (info is Map && info.containsKey("correcta")) {
        return info["correcta"];
      }
    }

    if (limpia.isEmpty) return palabra;

    String norm = normalizar(limpia);
    String fon = fonetizar(limpia);

    String mejor = palabra;
    int mejorScore = 999;

    List<String> candidatos = [...palabrasClave, ...diccionario];

    for (var d in candidatos) {
      String dNorm = normalizar(d);
      String dFon = fonetizar(d);

      int score = dist(norm, dNorm) + dist(fon, dFon) * 2;
      score += (palabra.length - d.length).abs();

      if (score < mejorScore && score <= 4) {
        mejorScore = score;
        mejor = d;
      }
    }

    return mejor;
  }

  String corregirTexto(String texto) =>
      texto.split(RegExp(r'\s+')).map(corregirPalabra).join(" ");

  String corregirContexto(String texto) {
    String resultado = texto.toLowerCase();

    // corregir unigramas
    for (String uni in unigramas) {
      resultado = resultado.replaceAllMapped(
        RegExp('\\b\\w+\\b', caseSensitive: false),
        (m) =>
            m.group(0)!.toLowerCase() == uni.toLowerCase() ? uni : m.group(0)!,
      );
    }

    // corregir bigramas
    for (String bi in bigramas) {
      List<String> partes = bi.split(" ");

      if (partes.length != 2) continue;

      String p1 = partes[0];
      String p2 = partes[1];

      resultado = resultado.replaceAllMapped(
        RegExp('$p1\\s+\\w+', caseSensitive: false),

        (_) => bi,
      );
    }
    // corregir trigramas
    for (String trig in trigramas) {
      List<String> partes = trig.split(" ");

      if (partes.length != 3) continue;

      String p1 = partes[0];
      String p2 = partes[1];
      String p3 = partes[2];

      resultado = resultado.replaceAllMapped(
        RegExp('$p1\\s+$p2\\s+\\w+', caseSensitive: false),

        (_) => trig,
      );
    }

    // corregir cuatrigramas
    for (String cuatri in cuatrigramas) {
      List<String> partes = cuatri.split(" ");

      if (partes.length != 4) continue;

      String p1 = partes[0];
      String p2 = partes[1];
      String p3 = partes[2];
      String p4 = partes[3];

      resultado = resultado.replaceAllMapped(
        RegExp('$p1\\s+$p2\\s+$p3\\s+\\w+', caseSensitive: false),

        (_) => cuatri,
      );
    }

    return resultado;
  }

  // =========@======= FILTRO DE IDIOMA  ==========
  Future<String> filtrarTextoOCR(String texto) async {
    List<String> resultado = [];

    final detector = LanguageIdentifier(confidenceThreshold: 0.5);

    for (String linea in texto.split('\n')) {
      String l = linea.trim().toLowerCase();

      bool contienePalabraUtil = palabrasAlimentos.any((p) => l.contains(p));

      if (!contienePalabraUtil && l.length < 10) {
        continue;
      }

      if (l.isEmpty) continue;

      // URLs
      if (l.contains("www.")) continue;
      if (l.contains(".com")) continue;
      if (l.contains(".es")) continue;

      // códigos de barras y números largos
      if (RegExp(r'^\d{6,}$').hasMatch(l.replaceAll(' ', ''))) {
        continue;
      }

      // pesos
      if (RegExp(r'^\d+\s*(g|kg|ml|cl|l)$').hasMatch(l)) {
        continue;
      }

      // líneas demasiado cortas
      if (l.length < 3) continue;

      // reciclaje
      if (l.contains("recicla")) continue;
      if (l.contains("separa")) continue;
      if (l.contains("amarillo")) continue;
      if (l.contains("contenedor")) continue;
      if (l.contains("bolsita")) continue;
      if (l.contains("envase")) continue;

      // marcas logísticas
      if (l.contains("lote")) continue;

      // inglés conocido
      bool esIngles = palabrasIngles.any((p) => l.contains(p));

      if (esIngles) continue;

      String idioma;

      try {
        idioma = await detector.identifyLanguage(linea);
      } catch (_) {
        continue;
      }

      if (idioma == "es" || idioma == "und") {
        resultado.add(linea);
      }
    }

    detector.close();

    return resultado.join('\n');
  }

  // ================= DICCIONARIO =================
  Future<void> cargarDiccionario() async {
    //
    final data = await rootBundle.loadString('assets/diccionario_es.json');
    diccionario = List<String>.from(jsonDecode(data));
  }

  // ==========@====== N-GRAMAS =================
  Future<void> cargarNGramas() async {
    final data = await rootBundle.loadString('assets/ngramas_alimentos.json');
    final jsonData = jsonDecode(data);
    unigramas = List<String>.from(jsonData["unigramas"]);
    bigramas = List<String>.from(jsonData["bigramas"]);
    trigramas = List<String>.from(jsonData["trigramas"]);
    cuatrigramas = List<String>.from(jsonData["cuatrigramas"]);
  }

  // ================= ALÉRGENOS =================
  final Map<String, List<String>> alergenos = {
    "gluten": ["trigo", "cebada", "centeno", "gluten"],
    "lácteos": ["leche", "lactosa"],
    "huevo": ["huevo"],
    "frutos secos": ["almendra", "avellana", "nuez"],
    "cacahuete": ["cacahuete", "mani"],
    "soja": ["soja"],
    "pescado": ["pescado"],
    "marisco": ["marisco"],
  };

  List<String> detectarAlergenos(String texto) {
    final t = normalizar(texto);
    List<String> res = [];

    alergenos.forEach((k, v) {
      if (v.any((p) => t.contains(p))) res.add(k);
    });

    return res;
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _tts.setLanguage("es-ES");
    await _tts.setSpeechRate(0.5);
    await cargarDiccionario();
    await cargarNGramas();
    await cargarErroresOCR();
    await cargarDiccionarioAdaptativo();

    await integrarErroresEnDiccionario();
    await _procesar();
  }

  Future<void> _procesar() async {
    final input = InputImage.fromFilePath(widget.imagePath);
    final recognizer = TextRecognizer();
    final result = await recognizer.processImage(input);

    // OCR bruto
    ultimoOCRBruto = result.text.isEmpty ? "No hay texto" : result.text;

    // OCR filtrado
    ultimoOCROriginal = await filtrarTextoOCR(ultimoOCRBruto);

    // Corrección diccionario
    String textoCorregido = corregirTexto(ultimoOCROriginal);

    // Corrección por contexto
    // textoCorregido = corregirContexto(textoCorregido); // DESACTIVADO PARA EVALUACIÓN

    ultimoOCRCorregido = textoCorregido;

    // Detección alérgenos
    final alerg = detectarAlergenos(textoCorregido);

    String mensaje = alerg.isNotEmpty
        ? "Atención contiene ${alerg.join(", ")}"
        : "No se detectan alérgenos";

    setState(() {
      _resultado = "$mensaje\n\n$textoCorregido";
    });

    await _tts.speak(mensaje);
    await _tts.speak(textoCorregido);

    recognizer.close();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Resultado")),
      body: Column(
        children: [
          SizedBox(
            height: 250,
            child: Image.file(File(widget.imagePath), fit: BoxFit.contain),
          ),

          Expanded(
            child: Card(
              margin: const EdgeInsets.all(10),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: SelectableText(
                  _resultado,
                  style: const TextStyle(fontSize: 18, height: 1.5),
                ),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: realController,
              maxLines: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Texto real (Ground Truth)",
              ),
            ),
          ),

          ElevatedButton.icon(
            onPressed: guardarEvaluacion,
            icon: const Icon(Icons.science),
            label: const Text("GUARDAR EXPERIMENTO"),
          ),

          ElevatedButton.icon(
            onPressed: () => _tts.speak(_resultado),
            icon: const Icon(Icons.volume_up),
            label: const Text("REPETIR LECTURA"),
          ),
        ],
      ),
    );
  }

  double calcularCER(String real, String pred) {
    real = normalizarWER(real);
    pred = normalizarWER(pred);
    return dist(real, pred) / max(real.length, 1); // evitar división por cero
  }

  double calcularWER(String real, String pred) {
    real = normalizarWER(real);
    pred = normalizarWER(pred);
    List<String> r = real.split(
      RegExp(r'\s+'),
    ); // dividir en palabras usando espacios como separadores
    List<String> p = pred.split(RegExp(r'\s+'));

    int m = r.length;
    int n = p.length;

    List<List<int>> dp = List.generate(m + 1, (_) => List.filled(n + 1, 0));

    for (int i = 0; i <= m; i++) {
      dp[i][0] = i;
    }

    for (int j = 0; j <= n; j++) {
      dp[0][j] = j;
    }

    for (int i = 1; i <= m; i++) {
      for (int j = 1; j <= n; j++) {
        int cost = r[i - 1] == p[j - 1] ? 0 : 1;

        dp[i][j] = [
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + cost,
        ].reduce(min);
      }
    }

    return dp[m][n] / max(m, 1);
  }

  Future<void> guardarEvaluacion() async {
    String textoReal = realController.text.trim();

    if (textoReal.isEmpty) {
      return;
    }

    String ocrOriginal = ultimoOCROriginal;
    String ocrCorregido = ultimoOCRCorregido;
    String textoRealNorm = normalizarWER(textoReal);
    String ocrOriginalNorm = normalizarWER(ocrOriginal);
    String ocrCorregidoNorm = normalizarWER(ocrCorregido);
    double cerOCR = calcularCER(textoRealNorm, ocrOriginalNorm);
    double cerCorregido = calcularCER(textoRealNorm, ocrCorregidoNorm);
    double werOCR = calcularWER(textoRealNorm, ocrOriginalNorm);
    double werCorregido = calcularWER(textoRealNorm, ocrCorregidoNorm);

    final carpeta = await obtenerCarpetaTFM();
    final nombre = DateTime.now().millisecondsSinceEpoch;

    await File(
      '${carpeta.path}/ocr_$nombre.txt',
    ).writeAsString(ultimoOCROriginal); // GUARDAR TEXTO ORIGINAL

    await File(
      '${carpeta.path}/ocr_corregido_$nombre.txt',
    ).writeAsString(ultimoOCRCorregido);

    final datos = {
      "fecha": DateTime.now().toIso8601String(),
      "imagen": widget.imagePath,
      "texto_real": textoReal, // GUARDAR TEXTO REAL
      "ocr_bruto": ultimoOCRBruto, // GUARDAR TEXTO BRUTO
      "ocr_original": ocrOriginal, // GUARDAR TEXTO ORIGINAL
      "ocr_corregido": ocrCorregido, // GUARDAR TEXTO CORREGIDO
      "cer_ocr": cerOCR, // GUARDAR CER ORIGINAL
      "cer_corregido": cerCorregido, // GUARDAR CER CORREGIDO
      "wer_ocr": werOCR, // GUARDAR WER ORIGINAL
      "wer_corregido": werCorregido, // GUARDAR WER CORREGIDO
      "tiempo_captura_ms": MetricasRendimiento.tiempoCaptura, // GUARDAR TIEMPO DE CAPTURA
    };

    await File(
      '${carpeta.path}/exp_$nombre.json',
    ).writeAsString(const JsonEncoder.withIndent('  ').convert(datos));

    await EvaluacionOCR.guardarExperimento(
      imagen: widget.imagePath,
      textoReal: textoReal,
      ocr: ocrOriginal,
      corregido: ocrCorregido,
      cerOCR: cerOCR,
      cerCorregido: cerCorregido,
      werOCR: werOCR,
      werCorregido: werCorregido,
      tiempoCaptura: MetricasRendimiento.tiempoCaptura,
    );

    if (!mounted) return;

    aprenderErroresOCR(textoReal, ocrOriginal);

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Experimento guardado")));
  }

  // ================= CARGAR ERRORES OCR =================
  Future<void> cargarErroresOCR() async {
    final carpeta = await obtenerCarpetaTFM();

    final fichero = File('${carpeta.path}/errores_ocr.json');

    if (await fichero.exists()) {
      erroresOCR = Map<String, dynamic>.from(
        jsonDecode(await fichero.readAsString()),
      );
    }
  }

  // ================= GUARDAR ERRORES OCR =================

  Future<void> guardarErroresOCR() async {
    final carpeta = await obtenerCarpetaTFM();

    final fichero = File('${carpeta.path}/errores_ocr.json');

    await fichero.writeAsString(
      const JsonEncoder.withIndent(" ").convert(erroresOCR),
    );
  }

  // ================= STOP WORDS =================

  static const Set<String> stopWords = {
    "de",
    "la",
    "el",
    "en",
    "un",
    "una",
    "y",
    "o",
    "es",
    "al",
    "del",
    "los",
    "las",
    "por",
    "con",
    "sin",
    "que",
    "para",
    "se",
    "su",
  };

  // ================= NUMEROS =================

  bool esNumero(String texto) {
    return RegExp(r'^\d+$').hasMatch(texto);
  }

  // ================ APRENDER ERRORES OCR =================

  Future<void> aprenderErroresOCR(String textoReal, String ocr) async {
    List<String> real = normalizarWER(textoReal).split(RegExp(r'\s+'));

    List<String> detectado = normalizarWER(ocr).split(RegExp(r'\s+'));

    int n = min(real.length, detectado.length);

    for (int i = 0; i < n; i++) {
      String palabraReal = real[i].toLowerCase().trim();
      String palabraOCR = detectado[i].toLowerCase().trim();

      // Ignorar cadenas vacías
      if (palabraReal.isEmpty || palabraOCR.isEmpty) {
        continue;
      }

      // Ignorar si son iguales
      if (palabraReal == palabraOCR) {
        continue;
      }

      // Ignorar palabras muy cortas
      if (palabraReal.length < 3 || palabraOCR.length < 3) {
        continue;
      }

      // Ignorar números
      if (esNumero(palabraReal) || esNumero(palabraOCR)) {
        continue;
      }

      // Ignorar stopwords
      if (stopWords.contains(palabraReal) || stopWords.contains(palabraOCR)) {
        continue;
      }

      // Distancia Levenshtein
      int distancia = dist(palabraReal, palabraOCR);

      // Solo aprender errores razonables
      if (distancia <= 2) {
        if (erroresOCR.containsKey(palabraOCR)) {
          erroresOCR[palabraOCR]["frecuencia"]++;
        } else {
          erroresOCR[palabraOCR] = {"correcta": palabraReal, "frecuencia": 1};
        }

        print(
          "Aprendido: $palabraOCR -> $palabraReal "
          "(dist=$distancia)",
        );
      }
    }

    await guardarErroresOCR();
  }

  // CARGAR DICCIONARIO ADAPTATIVO
  Future<void> cargarDiccionarioAdaptativo() async {
    final carpeta = await obtenerCarpetaTFM();

    final fichero = File('${carpeta.path}/diccionario_adaptativo.json');

    if (await fichero.exists()) {
      diccionarioAdaptativo = Set<String>.from(
        jsonDecode(await fichero.readAsString()),
      );
    }
  }

  // GUARDAR DICCIONARIO ADAPTATIVO
  Future<void> guardarDiccionarioAdaptativo() async {
    final carpeta = await obtenerCarpetaTFM();

    final fichero = File('${carpeta.path}/diccionario_adaptativo.json');

    await fichero.writeAsString(
      const JsonEncoder.withIndent(" ").convert(diccionarioAdaptativo.toList()),
    );
  }

  Future<void> integrarErroresEnDiccionario() async {
    erroresOCR.forEach((error, info) {
      if (info["frecuencia"] >= 3) {
        diccionarioAdaptativo.add(info["correcta"]);
      }
    });

    await guardarDiccionarioAdaptativo();
  }
}
